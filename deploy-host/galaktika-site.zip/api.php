<?php
// Галактика — серверная часть для обычного хостинга (PHP 7.4+).
// Повторяет API galaktika.Web: /api/auth/login, /register, /me, /profile, /password, /health.
// Формат users.json и PBKDF2 совместимы с AuthStore.cs:
//   PBKDF2-SHA256, 120000 итераций, 32 байта, соль 16 байт, base64.

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$action = isset($_GET['action']) ? $_GET['action'] : '';
if ($action === '') {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (preg_match('#/api/auth/([a-zA-Z]+)#', $path, $m)) $action = $m[1];
    elseif (strpos($path, '/api/health') === 0) $action = 'health';
}

$docroot = __DIR__;
$candidates = array(
    dirname($docroot) . '/galaktika-data',   // предпочтительно: рядом с сайтом, вне веб-корня
    $docroot . '/data',
);
$dataDir = null;
foreach ($candidates as $dir) {
    if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
    if (is_dir($dir) && is_writable($dir)) { $dataDir = $dir; break; }
}
if ($dataDir === null) {
    http_response_code(500);
    echo json_encode(array('error' => 'нет каталога для данных'));
    exit;
}

$usersFile  = $dataDir . '/users.json';
$tokensFile = $dataDir . '/tokens.json';

function json_out($code, $payload) {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function load_json($file, $default) {
    if (!file_exists($file)) return $default;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $default;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}

function save_json($file, $data) {
    $tmp = $file . '.tmp';
    file_put_contents($tmp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    @rename($tmp, $file);
}

function norm($email) { return strtolower(trim((string)$email)); }

function find_user(&$users, $email) {
    $n = norm($email);
    foreach ($users as $i => $u) {
        if (norm(isset($u['Email']) ? $u['Email'] : '') === $n) return $i;
    }
    return -1;
}

function hash_password($password) {
    $salt = random_bytes(16);
    $hash = hash_pbkdf2('sha256', $password, $salt, 120000, 32, true);
    return array(base64_encode($salt), base64_encode($hash));
}

function verify_password($password, $saltB64, $hashB64) {
    $salt = base64_decode($saltB64, true);
    $expected = base64_decode($hashB64, true);
    if ($salt === false || $expected === false) return false;
    $actual = hash_pbkdf2('sha256', $password, $salt, 120000, 32, true);
    return hash_equals($expected, $actual);
}

function issue_token($email) {
    global $tokensFile;
    $tokens = load_json($tokensFile, array());
    $token = bin2hex(random_bytes(24));
    $tokens[$token] = norm($email);
    save_json($tokensFile, $tokens);
    return $token;
}

function user_by_token($token) {
    global $tokensFile, $usersFile;
    if (!$token) return null;
    $tokens = load_json($tokensFile, array());
    if (!isset($tokens[$token])) return null;
    $users = load_json($usersFile, array());
    $idx = find_user($users, $tokens[$token]);
    return $idx >= 0 ? $users[$idx] : null;
}

$users = load_json($usersFile, array());
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = array();
$token = isset($_SERVER['HTTP_X_AUTH_TOKEN']) ? $_SERVER['HTTP_X_AUTH_TOKEN'] : '';

$method = $_SERVER['REQUEST_METHOD'];

switch ($action) {
    case 'health':
        json_out(200, array('ok' => true, 'time' => gmdate('c')));

    case 'login':
        if ($method !== 'POST') json_out(405, array('error' => 'method'));
        $email = isset($input['email']) ? $input['email'] : '';
        $password = isset($input['password']) ? $input['password'] : '';
        $idx = find_user($users, $email);
        if ($idx < 0 || !verify_password($password, $users[$idx]['Salt'], $users[$idx]['Hash'])) {
            json_out(401, array('error' => 'invalid credentials'));
        }
        $u = $users[$idx];
        json_out(200, array(
            'token' => issue_token($u['Email']),
            'role' => $u['Role'],
            'profile' => $u['Profile'],
        ));

    case 'register':
        if ($method !== 'POST') json_out(405, array('error' => 'method'));
        $email = norm(isset($input['email']) ? $input['email'] : '');
        $password = isset($input['password']) ? $input['password'] : '';
        if (strlen($email) < 3 || strpos($email, '@') === false) json_out(400, array('error' => 'неверная почта'));
        if (strlen($password) < 6) json_out(400, array('error' => 'пароль короче 6 символов'));
        if (find_user($users, $email) >= 0) json_out(400, array('error' => 'такая почта уже есть'));

        list($salt, $hash) = hash_password($password);
        $profile = json_encode(array(
            'lastName' => isset($input['lastName']) ? $input['lastName'] : '',
            'gameName' => isset($input['gameName']) ? $input['gameName'] : '',
            'faction' => isset($input['faction']) ? $input['faction'] : '',
            'credits' => 80000,
            'hasSeenLegend' => false,
        ), JSON_UNESCAPED_UNICODE);

        $users[] = array(
            'Email' => $email,
            'Salt' => $salt,
            'Hash' => $hash,
            'Profile' => $profile,
            'Role' => ($email === 'ab@btema.ru') ? 'admin' : 'user',
            'Created' => gmdate('c'),
        );
        save_json($usersFile, $users);
        json_out(200, array('token' => issue_token($email), 'role' => end($users)['Role'], 'profile' => $profile));

    case 'me':
        $u = user_by_token($token);
        if (!$u) json_out(401, array('error' => 'unauthorized'));
        json_out(200, array('email' => $u['Email'], 'role' => $u['Role'], 'profile' => $u['Profile']));

    case 'profile':
        $u = user_by_token($token);
        if (!$u) json_out(401, array('error' => 'unauthorized'));
        $profile = isset($input['profile']) ? $input['profile'] : '';
        if ($profile === '') json_out(400, array('error' => 'empty profile'));
        $idx = find_user($users, $u['Email']);
        $users[$idx]['Profile'] = $profile;
        save_json($usersFile, $users);
        json_out(200, array('saved' => true));

    case 'password':
        $u = user_by_token($token);
        if (!$u) json_out(401, array('error' => 'unauthorized'));
        $old = isset($input['oldPassword']) ? $input['oldPassword'] : '';
        $new = isset($input['newPassword']) ? $input['newPassword'] : '';
        if (!verify_password($old, $u['Salt'], $u['Hash']) || strlen($new) < 6) {
            json_out(400, array('error' => 'не удалось сменить пароль'));
        }
        list($salt, $hash) = hash_password($new);
        $idx = find_user($users, $u['Email']);
        $users[$idx]['Salt'] = $salt;
        $users[$idx]['Hash'] = $hash;
        save_json($usersFile, $users);
        json_out(200, array('changed' => true));

    default:
        json_out(404, array('error' => 'unknown endpoint'));
}
